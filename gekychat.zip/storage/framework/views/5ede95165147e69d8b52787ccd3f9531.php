

<?php $__env->startSection('content'); ?>
<style>
  .wa-card{background:var(--card);border:1px solid var(--border);border-radius:18px;box-shadow:var(--wa-shadow);}
  .btn-wa{background:var(--wa-green);border:none;color:#062a1f;font-weight:600;border-radius:14px;}
  .avatar-preview{width:96px;height:96px;border-radius:50%;object-fit:cover;border:1px solid var(--border);}
</style>

<div class="container py-4">
  <div class="row justify-content-center">
    <div class="col-12 col-lg-7">
      <div class="wa-card p-3 p-md-4">
        <h5 class="mb-3">Profile</h5>

        <?php if(session('status')): ?> <div class="alert alert-success"><?php echo e(session('status')); ?></div> <?php endif; ?>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
        <?php endif; ?>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <div class="mb-3 d-flex align-items-center gap-3">
            <img id="avatarPreview" class="avatar-preview"
                 src="<?php echo e($user->avatar_path ? asset('storage/'.$user->avatar_path) : asset('icons/icon-192x192.png')); ?>" alt="">
            <div>
              <label class="form-label mb-1">Photo</label>
              <input type="file" name="avatar" class="form-control" accept="image/*" onchange="previewAvatar(event)">
              <small class="text-muted">JPG/PNG up to 2MB</small>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Display Name</label>
            <input class="form-control" type="text" name="name" maxlength="60" value="<?php echo e(old('name', $user->name)); ?>" placeholder="Your name">
          </div>

          <div class="mb-3">
            <label class="form-label">About</label>
            <input class="form-control" type="text" name="about" maxlength="160" value="<?php echo e(old('about', $user->about)); ?>" placeholder="Hey there! I am using GekyChat.">
          </div>

          <div class="mb-3">
            <label class="form-label">Phone</label>
            <input class="form-control" type="text" value="<?php echo e($user->phone); ?>" disabled>
            <small class="text-muted">Phone is your login. Email & password can be added later for 2FA.</small>
          </div>

          <button class="btn btn-wa px-4" type="submit">Save</button>
          <a href="<?php echo e(route('chat.index')); ?>" class="btn btn-outline-secondary ms-2">Back</a>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  function previewAvatar(e){
    const [file] = e.target.files;
    if (file) document.getElementById('avatarPreview').src = URL.createObjectURL(file);
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\gekychat\resources\views/profile/edit.blade.php ENDPATH**/ ?>