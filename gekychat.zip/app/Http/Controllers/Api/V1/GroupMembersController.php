<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\DB;

class GroupMembersController extends Controller
{
    /**
     * POST /api/v1/groups/{group}/members/phones
     * Body: { "phones": ["0551234567", "+233551234567", ...] }
     * Auth: sanctum
     */
    public function addByPhones(Request $request, Group $group)
    {
        Gate::authorize('manage-group', $group);

        $data = $request->validate([
            'phones'   => ['required', 'array', 'min:1'],
            'phones.*' => ['string', 'max:32'],
        ]);

        $phones = collect($data['phones'])
            ->map(fn ($p) => trim($p))
            ->filter()
            ->unique()
            ->values();

        if ($phones->isEmpty()) {
            return response()->json([
                'status' => 'ok',
                'group_id' => $group->id,
                'added_user_ids' => [],
                'already_members' => [],
                'not_found' => [],
            ]);
        }

        // Same tolerant matching approach as the resolver
        $last9Set = $phones
            ->map(fn ($p) => preg_replace('/\D+/', '', $p))
            ->map(fn ($digits) => strlen($digits) >= 9 ? substr($digits, -9) : $digits)
            ->filter()
            ->unique()
            ->values();

        $users = User::query()
            ->whereIn('phone', $phones)
            ->orWhere(function ($q) use ($last9Set) {
                foreach ($last9Set as $last9) {
                    $q->orWhereRaw('RIGHT(REGEXP_REPLACE(phone, "[^0-9]", ""), 9) = ?', [$last9]);
                }
            })
            ->get(['id', 'phone']);

        // Index by normalized last-9 for a quick reverse lookup
        $byLast9 = $users->keyBy(function ($u) {
            $digits = preg_replace('/\D+/', '', $u->phone ?? '');
            return strlen($digits) >= 9 ? substr($digits, -9) : $digits;
        });

        $attach = [];
        $added = [];
        $already = [];
        $notFound = [];

        // Pull existing member ids
        $existingIds = $group->members()->pluck('users.id')->all();
        $existingMap = array_flip($existingIds);

        foreach ($phones as $p) {
            $digits = preg_replace('/\D+/', '', $p);
            $last9  = strlen($digits) >= 9 ? substr($digits, -9) : $digits;

            $user = $users->firstWhere('phone', $p) ?: ($byLast9[$last9] ?? null);

            if (!$user) {
                $notFound[] = $p;
                continue;
            }

            if (isset($existingMap[$user->id])) {
                $already[] = $user->id;
                continue;
            }

            $attach[$user->id] = ['role' => 'member', 'joined_at' => now()];
            $added[] = $user->id;
        }

        if (!empty($attach)) {
            DB::transaction(function () use ($group, $attach) {
                $group->members()->syncWithoutDetaching($attach);
            });
        }

        return response()->json([
            'status'          => 'success',
            'group_id'        => $group->id,
            'added_user_ids'  => array_values(array_unique($added)),
            'already_members' => array_values(array_unique($already)),
            'not_found'       => array_values(array_unique($notFound)),
        ]);
    }
}
